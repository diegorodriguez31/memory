package Controleurs;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.JMenuItem;

import Main.Main;

public class ControleurDifficulte implements ActionListener{

	private Main main;

	
	public ControleurDifficulte(Main main) {
		this.main = main;
	}
	
	//Attribue � la variable qui stocke la difficult� la valeur du bouton cliqu� par le joueur
	public void actionPerformed(ActionEvent e) {
		JMenuItem b = (JMenuItem) e.getSource();
		if(b.getText() == "Facile") {
			try {
				this.main.setDifficulte(1);
			} catch (UnsupportedAudioFileException | IOException | LineUnavailableException e1) {
				System.out.println("Erreur lors de l'ouverture du fichier audio");
				e1.printStackTrace();
			}
		}else if (b.getText() == "Normal") {
			try {
				this.main.setDifficulte(2);
			} catch (UnsupportedAudioFileException | IOException | LineUnavailableException e1) {
				System.out.println("Erreur lors de l'ouverture du fichier audio");
				e1.printStackTrace();
			}
		}
	}
}