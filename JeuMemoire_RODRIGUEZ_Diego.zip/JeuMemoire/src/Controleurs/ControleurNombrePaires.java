package Controleurs;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.JMenuItem;

import Main.Main;

public class ControleurNombrePaires implements ActionListener{

	private Main main;
	
	public ControleurNombrePaires(Main main) {
		this.main = main;
	}
	
	//R�cup�re la valeur du bouton correspondant au nombre de paires (2,3,4...) afin d'attribuer cette valeur � la variable qui g�re le nombre de paires
	public void actionPerformed(ActionEvent e) {
		JMenuItem item = (JMenuItem) e.getSource();

		int nombreDePaires = Integer.parseInt(item.getText());
		try {
			this.main.changerNombrePaires(nombreDePaires);
		} catch (UnsupportedAudioFileException | IOException | LineUnavailableException e1) {
			System.out.println("Erreur lors de l'ouverture du fichier audio");
			e1.printStackTrace();
		}
	}
}
