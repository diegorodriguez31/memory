package Controleurs;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

import Main.Main;

public class ControleurQuitter implements ActionListener{
	
	
	public ControleurQuitter(Main main) {
	//Pas besoin d'instancier cette classe
	}
	
	//Affiche une fen�tre pop-up qui demande au joueur s'il veut bien quitter l'application
	public void actionPerformed(ActionEvent e) {
		int res = JOptionPane.showConfirmDialog(null, "La progression sera perdue si vous quittez", "Quitter ?", JOptionPane.YES_NO_OPTION);
		switch (res) {
		case JOptionPane.NO_OPTION:
			break;
		
		case JOptionPane.YES_OPTION:	
			System.exit(0);		
			break;
			
		default:
			break;
		}
	}
}