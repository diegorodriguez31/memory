package Controleurs;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.JOptionPane;

import Main.Main;

public class ControleurRecommencer implements ActionListener{

	private Main main;
	
	public ControleurRecommencer(Main main) {
		this.main = main;
	}
	
	//Affiche une fen�tre pop-up qui demande au joueur s'il veut recommencer. Il peut choisir, oui, non ou annuler
	public void actionPerformed(ActionEvent e) {
		int res = JOptionPane.showConfirmDialog(null, "Voulez vous recommencer ?");
		switch (res) {
		case JOptionPane.NO_OPTION:
			break;
		
		case JOptionPane.YES_OPTION:	
			try {
				this.main.creerNouvelleVue();
			} catch (UnsupportedAudioFileException | IOException | LineUnavailableException e1) {
				e1.printStackTrace();
			}
						
			break;
		case JOptionPane.CANCEL_OPTION:
			break;
			
		default:
			break;
		}
	}
}
