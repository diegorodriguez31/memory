package Controleurs;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.JMenuItem;

import Main.Main;

public class ControleurTableau implements ActionListener{
	
	private Main main;
	
	public ControleurTableau(Main main) {
		this.main = main;
	}
	
	//Change le type de tableau en fonction de ce que s�lectionne le joueur : tableau d'images ou tableau de couleurs
	public void actionPerformed(ActionEvent e) {
		JMenuItem b = (JMenuItem) e.getSource();

		if(b.getText() == "Paires de couleurs") {
			try {
				this.main.setTypeTableau(false);
			} catch (UnsupportedAudioFileException | IOException | LineUnavailableException e1) {
				System.out.println("Erreur lors de l'ouverture du fichier audio");
				e1.printStackTrace();
			}
		}else if (b.getText() == "Paires d'images") {
			try {
				this.main.setTypeTableau(true);
			} catch (UnsupportedAudioFileException | IOException | LineUnavailableException e1) {
				System.out.println("Erreur lors de l'ouverture du fichier audio");
				e1.printStackTrace();
			}
		}
	}

}