package Controleurs;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JOptionPane;

import Main.Vue_JeuMemoire;

public class Controleur_JeuMemoire implements ActionListener {

	//Les trois �tats du controleur
	enum Etat {
		DEBUT_COMBINAISON, PREMIER_BOUTON_CHOISI, DEUXIEME_BOUTON_CHOISI
	}

	private Etat etat;
	private Vue_JeuMemoire vue;
	public static int nbCoups = 0;
	private JButton premierBoutonChoisi; //Permet de sauvegarder le premier bouton s�lectionn�
	private JButton deuxiemeBoutonChoisi; //Permet de sauvegarder le deuxi�me bouton s�lectionn�
	private int nombreDePairesATrouver;
	private int nombreDePairesTrouvees;	
	public Clip clip; //Variable qui traitera les fichiers audios

	//Ces exceptions seront report�es un peu partout dans le code. Elles sont li�es aux traitement des fichiers audios
	public Controleur_JeuMemoire(Vue_JeuMemoire vue)
			throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		this.vue = vue; // on associe la vue au contr�leur
		Controleur_JeuMemoire.nbCoups = 0; // On initialise le nombre de coups � 0
		this.etat = Etat.DEBUT_COMBINAISON; // Toujours initialiser au premier �tat
		this.nombreDePairesATrouver = this.vue.getNombreCases() / 2; // Le nombre de paire correspond aux nombre de
																		// cases divis� par 2

		// D�marrer la musique (dure 3min seulement pour que le fichier ne soit pas trop volumineux)
		this.musiqueDeFond();
	}
	
	//G�re tous les boutons de la vue (boutons des paires, Valider et Recommencer) sauf les boutons du menu
	@Override
	public void actionPerformed(ActionEvent e) {
		JButton b = (JButton) e.getSource();

		if (b.getText().equals("Recommencer")) {
			this.recommencer(); //traitement recommencer
			this.etat = Etat.DEBUT_COMBINAISON;
		} else {

			switch (this.etat) {
			case DEBUT_COMBINAISON:
				if (this.vue.appartientGrille(b)) {
					try {
						this.enregistrerPremierChoix(b); //traitement 1
					} catch (UnsupportedAudioFileException | IOException | LineUnavailableException e1) {
						System.out.println("Erreur lors de l'ouverture du fichier audio");
						e1.printStackTrace();
					}
				}
				this.etat = Etat.PREMIER_BOUTON_CHOISI;
				break;

			case PREMIER_BOUTON_CHOISI:
				if (this.vue.appartientGrille(b)) {
					try {
						this.enregistrerDeuxiemeChoix(b); //traitement 2
					} catch (UnsupportedAudioFileException | IOException | LineUnavailableException e1) {
						System.out.println("Erreur lors de l'ouverture du fichier audio");
						e1.printStackTrace();
					}
					this.etat = Etat.DEUXIEME_BOUTON_CHOISI;
				}
				break;
			case DEUXIEME_BOUTON_CHOISI:
				if (b.getText() == "Valider") {
					if(this.getTypeTableau()) {
						this.traitementImage(b); //Traitements 4 ou (5 et 6) � l'int�rieur de la m�thode
					}else {
						this.traitementCouleur(b); //Traitements 4 ou (5 et 6) � l'int�rieur de la m�thode
					}
					
				} else {
					// Seul le mode "facile" permet cela. L'utilisateur peut valider quand il le
					// souhaite
					if(this.vue.getDifficulte() == 1) {
						try {
							this.modeFacile(b); //traitement mode facile
						} catch (UnsupportedAudioFileException | IOException | LineUnavailableException e1) {
							System.out.println("Erreur lors de l'ouverture du fichier audio");
							e1.printStackTrace();
						}
					}
					break; // On sort du switch pour ne pas compter le coup (sp�cifique au mode facile)
				}
				Controleur_JeuMemoire.nbCoups += 1; // On incr�mente le nombre de coups
				this.vue.nbCoups.setText("Nombre de coups :     " + Controleur_JeuMemoire.nbCoups); // On affiche le nombre de coups

				// Si toutes les paires ont �t� trouv�es
				if (this.nombreDePairesTrouvees == this.nombreDePairesATrouver) {
					try {
						this.finDuJeu(); //traitements 7 et 8
					} catch (UnsupportedAudioFileException | IOException | LineUnavailableException e1) {
						System.out.println("Erreur lors de l'ouverture du fichier audio");
						e1.printStackTrace();
					}
				} else {
					this.etat = Etat.DEBUT_COMBINAISON;
				}
				break;

			default:
				break;
			}
		}
	}

	//traitement 1
	public void enregistrerPremierChoix(JButton b)
			throws UnsupportedAudioFileException, IOException, LineUnavailableException {

		this.bruitageClic(); //traitement 3

		int i = this.vue.quelleCase(b);
		if(this.getTypeTableau()) {
			b.setIcon(this.vue.getImages()[i]);
			b.setDisabledIcon(this.vue.getImages()[i]);
		}else {
			b.setBackground(this.vue.getCouleurs()[i]);
		}
		b.setEnabled(false);
		this.premierBoutonChoisi = b;
	}

	//traitement 2
	public void enregistrerDeuxiemeChoix(JButton b)
			throws UnsupportedAudioFileException, IOException, LineUnavailableException {

		this.bruitageClic(); //traitement 3

		int i = this.vue.quelleCase(b);
		if(this.getTypeTableau()) {
			b.setIcon(this.vue.getImages()[i]);
			b.setDisabledIcon(this.vue.getImages()[i]);
		}else {
			b.setBackground(this.vue.getCouleurs()[i]);
		}
		b.setEnabled(false);
		this.deuxiemeBoutonChoisi = b;
	}

	//traitement 5
	public void traitementPaireCorrecte(JButton b) {
		this.premierBoutonChoisi.setEnabled(false);
		this.premierBoutonChoisi = null;
		this.deuxiemeBoutonChoisi.setEnabled(false);
		this.deuxiemeBoutonChoisi = null;
		this.nombreDePairesTrouvees += 1;
	}

	//traitement 4
	public void traitementPaireIncorrecte(JButton b) {
		if(this.getTypeTableau()) {
			this.premierBoutonChoisi.setIcon(null);
			this.deuxiemeBoutonChoisi.setIcon(null);
		}else {
			this.premierBoutonChoisi.setBackground(null);
			this.deuxiemeBoutonChoisi.setBackground(null);
		}
		this.premierBoutonChoisi.setEnabled(true);
		this.deuxiemeBoutonChoisi.setEnabled(true);
	}

	//traitement recommencer
	public void recommencer() {
		this.vue.reinitialiser();
		this.premierBoutonChoisi = null;
		this.deuxiemeBoutonChoisi = null;
		this.nombreDePairesTrouvees = 0;
		Controleur_JeuMemoire.nbCoups = 0;
		this.vue.nbCoups.setText("Nombre de coups :     0");
	}

	//traitement 7 et 8
	public void finDuJeu() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		this.bruitageVictoire(); //traitement 7
		ImageIcon winIcon = new ImageIcon("./Images/win.png");
		Image winImage = winIcon.getImage();
		Image winImageScaled = winImage.getScaledInstance(40, 40, java.awt.Image.SCALE_SMOOTH);
		winIcon = new ImageIcon(winImageScaled);
		JOptionPane.showMessageDialog(this.vue, "Bien jou� : vous avez r�ussi en " + Controleur_JeuMemoire.nbCoups + " coups",
				"Victoire", JOptionPane.INFORMATION_MESSAGE, winIcon);
	}

	//traitement mode facile
	public void modeFacile(JButton b) throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		this.premierBoutonChoisi.setEnabled(true);
		this.deuxiemeBoutonChoisi.setEnabled(true);

		if(this.getTypeTableau()) {
			this.premierBoutonChoisi.setIcon(null);
			this.deuxiemeBoutonChoisi.setIcon(null);
		}else {
			this.premierBoutonChoisi.setBackground(null);
			this.deuxiemeBoutonChoisi.setBackground(null);
		}
		this.premierBoutonChoisi = null;
		this.deuxiemeBoutonChoisi = null;

		enregistrerPremierChoix(b);
		this.etat = Etat.PREMIER_BOUTON_CHOISI;
	}

	//traitement 3
	public void bruitageClic() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		File bruitDuClic = new File("./Sons/Clic.wav");

		Clip clip = AudioSystem.getClip();

		// System.out.println(clip.getFormat()); Cette ligne me permettait de voir le
		// format audio que prend java (tr�s compliqu� de trouver le bon format)
		// J'ai donc cherch� sur internet un format de type "PCM_SIGNED 44100.0 Hz, 16
		// bit, stereo, 4 bytes/frame, little-endian"

		clip.open(AudioSystem.getAudioInputStream(bruitDuClic));
		clip.start();
	}

	//traitement 7
	public void bruitageVictoire() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		File bruitDuClic = new File("./Sons/win.wav");
		Clip clip = AudioSystem.getClip();
		clip.open(AudioSystem.getAudioInputStream(bruitDuClic));
		clip.start();
	}

	//traitement 6
	public void bruitageValider() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		File bruitDuClic = new File("./Sons/valider.wav");
		Clip clip = AudioSystem.getClip();
		clip.open(AudioSystem.getAudioInputStream(bruitDuClic));
		clip.start();
	}

	//traitement 9
	public void musiqueDeFond() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		File musique = new File("./Sons/laytonMusic.wav");
		this.clip = AudioSystem.getClip();
		this.clip.open(AudioSystem.getAudioInputStream(musique));
		this.clip.start();
	}
	
	//Traitements 4 ou (5 et 6)
	public void traitementImage(JButton b) {
		if(this.deuxiemeBoutonChoisi.getIcon().equals(this.premierBoutonChoisi.getIcon())) {
			this.traitementPaireCorrecte(b); //Traitement 5
			try {
				this.bruitageValider(); //Traitement 6
			} catch (UnsupportedAudioFileException | IOException | LineUnavailableException e1) {
				System.out.println("Erreur lors de l'ouverture du fichier audio");
				e1.printStackTrace();
			}
		} else {
			this.traitementPaireIncorrecte(b); //Traitement 4
		}
	}
	
	//Traitements 4 ou (5 et 6)
	public void traitementCouleur(JButton b) {
		if(this.deuxiemeBoutonChoisi.getBackground().equals(this.premierBoutonChoisi.getBackground())) {
			this.traitementPaireCorrecte(b); //Traitement 5
			try {
				this.bruitageValider(); //Traitement 6
			} catch (UnsupportedAudioFileException | IOException | LineUnavailableException e1) {
				System.out.println("Erreur lors de l'ouverture du fichier audio");
				e1.printStackTrace();
			}
		} else {
			this.traitementPaireIncorrecte(b); //Traitement 4
		}
	}
	
	public boolean getTypeTableau() {
		return this.vue.getTypeTableau();
	}
}