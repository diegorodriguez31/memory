package Main;
import java.io.IOException;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.JFrame;

public class Main{
    
    private JFrame frame;
    private Vue_JeuMemoire vue;
    private int nombreDePaires = 8;
    private int difficulte = 2;
    
	//SI true ALORS tableau d'images SINON tableau de couleurs
    private boolean typeTableau = true;
    
    	public static void main(String[] args) throws UnsupportedAudioFileException, IOException, LineUnavailableException {
    		new Main();
    	}
    	
    	public Main() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
    		this.frame = new JFrame();
			this.vue = new Vue_JeuMemoire(this.nombreDePaires*2, this.typeTableau, this.difficulte); //Vue_JeuMemoire attend en entr�e le nombre de paires, le type de tableau et la difficult�
			this.frame.add(vue);
			this.frame.setTitle("Trouver les paires");
			this.frame.setJMenuBar(new Menu_JeuMemoire(this));
			this.frame.setVisible(true);
			this.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //Permet de fermer l'application lorsque le joueur clique sur la croix
			this.frame.pack();
			this.frame.setLocationRelativeTo(null); //Permet de centrer la fen�tre

       	}
		
    	//Supprime la vue actuelle et en cr�e une nouvelle
		public void creerNouvelleVue() throws UnsupportedAudioFileException, IOException, LineUnavailableException{

			this.frame.remove(this.vue);
			this.vue.controleur.clip.stop();

			this.vue = new Vue_JeuMemoire(this.nombreDePaires*2, this.typeTableau, this.difficulte);
			this.frame.add(this.vue);
			
			this.frame.setVisible(true);
			this.frame.repaint();
			this.frame.pack();
			this.frame.setLocationRelativeTo(null);
			
		}
		
		//Actualise le nombre de paires et r�cr�e la vue avec ce nouveau param�tre
		public void changerNombrePaires(int nombreDePaires) throws UnsupportedAudioFileException, IOException, LineUnavailableException {
			this.nombreDePaires = nombreDePaires;
			this.creerNouvelleVue();
		}
		
		//Actualise le type de tableau et recr�e la vue avec ce nouveau param�tre
		public void setTypeTableau(boolean typeTableau) throws UnsupportedAudioFileException, IOException, LineUnavailableException {
			this.typeTableau = typeTableau;
			this.creerNouvelleVue();
		}
		
		//Actualise la difficult� du jeu et recr�e la vue avec ce nouveau param�tre
		public void setDifficulte(int difficulte) throws UnsupportedAudioFileException, IOException, LineUnavailableException {
			this.difficulte = difficulte;
			this.creerNouvelleVue();
		}
}
