package Main;

import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

import Controleurs.ControleurDifficulte;
import Controleurs.ControleurNombrePaires;
import Controleurs.ControleurQuitter;
import Controleurs.ControleurRecommencer;
import Controleurs.ControleurTableau;

public class Menu_JeuMemoire extends JMenuBar{
	
	private static final long serialVersionUID = 1L;
	private Main main;
	
	public Menu_JeuMemoire(Main main) {
		this.main = main;
		
		//On fabrique tous les boutons du menu et on y associe des contr�leurs sp�cifiques
		
		JMenu jeu = new JMenu("Jeu");
		
		JMenuItem recommencer = new JMenuItem("Recommencer");
		recommencer.addActionListener(new ControleurRecommencer(this.main));
		
		JMenuItem quitter = new JMenuItem("Quitter");
		quitter.addActionListener(new ControleurQuitter(this.main));
		
		jeu.add(recommencer);
		jeu.addSeparator();
		jeu.add(quitter);
		
		JMenu options = new JMenu("Options");
		this.add(options);
		
		JMenu nbPaires = new JMenu("Nombre de paires");
		JMenu typeTableau = new JMenu("Th�me");
		JMenu difficulte = new JMenu("Difficult�");
		
		options.add(nbPaires);
		options.add(typeTableau);
		options.add(difficulte);
		
		ControleurNombrePaires controleurNombrePaires = new ControleurNombrePaires(this.main);
		ControleurTableau controleurTableau = new ControleurTableau(this.main);
		ControleurDifficulte controleurDifficulte = new ControleurDifficulte(this.main);
		
		for(int i = 2; i <= 8; i++) {
			JMenuItem nombre = new JMenuItem(String.valueOf(i));
			nombre.addActionListener(controleurNombrePaires);
			nbPaires.add(nombre);
		}
		
		JMenuItem couleurs = new JMenuItem("Paires de couleurs");
		JMenuItem images = new JMenuItem("Paires d'images");

		couleurs.addActionListener(controleurTableau);
		images.addActionListener(controleurTableau);
		
		typeTableau.add(couleurs);
		typeTableau.add(images);
		
		
		JMenuItem facile = new JMenuItem("Facile");
		JMenuItem normal = new JMenuItem("Normal");
		
		facile.addActionListener(controleurDifficulte);
		normal.addActionListener(controleurDifficulte);
		
		difficulte.add(facile);
		difficulte.add(normal);
		
		this.add(jeu);
		this.add(options);
	}
}
