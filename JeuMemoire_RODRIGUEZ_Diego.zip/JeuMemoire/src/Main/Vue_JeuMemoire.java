package Main;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Image;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

import Controleurs.Controleur_JeuMemoire;

public class Vue_JeuMemoire extends JPanel {


	private static final long serialVersionUID = 1L;
	
	//Cr�ation des images
	private ImageIcon androidIcon = new ImageIcon(new ImageIcon("./Images/android.png").getImage().getScaledInstance(150, 150, Image.SCALE_DEFAULT));
	private ImageIcon cIcon = new ImageIcon(new ImageIcon("./Images/c.png").getImage().getScaledInstance(150, 150, Image.SCALE_DEFAULT));
	private ImageIcon javaIcon = new ImageIcon("./Images/java.png");
	private ImageIcon jsIcon = new ImageIcon(new ImageIcon("./Images/js.png").getImage().getScaledInstance(250, 150, Image.SCALE_DEFAULT));
	private ImageIcon phpIcon = new ImageIcon(new ImageIcon("./Images/php.png").getImage().getScaledInstance(150, 150, Image.SCALE_DEFAULT));
	private ImageIcon pythonIcon = new ImageIcon(new ImageIcon("./Images/python.png").getImage().getScaledInstance(150, 150, Image.SCALE_DEFAULT));
	private ImageIcon reactIcon = new ImageIcon(new ImageIcon("./Images/react.png").getImage().getScaledInstance(200, 150, Image.SCALE_DEFAULT));
	private ImageIcon swiftIcon = new ImageIcon(new ImageIcon("./Images/swift.png").getImage().getScaledInstance(150, 150, Image.SCALE_DEFAULT));

	//Tableau constante des couleurs
	private final Color couleursFinal[] = { Color.BLACK, Color.BLACK, Color.BLUE, Color.BLUE, Color.CYAN, Color.CYAN,
			Color.PINK, Color.PINK, Color.GRAY, Color.GRAY, Color.GREEN, Color.GREEN, Color.MAGENTA, Color.MAGENTA,
			Color.ORANGE, Color.ORANGE };
	//Tableau cosntante des images
	private final ImageIcon imagesFinal[] = {this.androidIcon, this.androidIcon, this.cIcon, this.cIcon, this.javaIcon, this.javaIcon, this.jsIcon, this.jsIcon, this.phpIcon, this.phpIcon,
			this.pythonIcon, this.pythonIcon, this.reactIcon, this.reactIcon, this.swiftIcon, this.swiftIcon };
	
	private Color couleurs[];

	public ImageIcon[] images;

	public JLabel nbCoups;

	private List<Color> couleursListe;
	private List<ImageIcon> imagesListe;

	private JButton[] tableauDesPaires;

	private int nombreDeCases;

	public Controleur_JeuMemoire controleur;
	
	//SI true ALORS tableau d'images SINON tableau de couleurs
	private boolean typeTableau;
	
	//Si 1 => facile | Si 2 => Normal
	private int difficulte;

	public Vue_JeuMemoire(int nombreDeCases, boolean typeTableau, int difficulte)
			throws UnsupportedAudioFileException, IOException, LineUnavailableException {

		// Initialisation des variables
		this.nombreDeCases = nombreDeCases;
		this.typeTableau = typeTableau;
		this.difficulte = difficulte;
		this.tableauDesPaires = new JButton[nombreDeCases];
		this.images = new ImageIcon[this.nombreDeCases];
		this.couleurs = new Color[this.nombreDeCases];

		//Cette condition v�rifie quel est le tableau, elle sera r�utilis�e plus tard
		if(this.typeTableau) {
			this.images = this.remplirTableauImages(this.images);
		}else {
			this.couleurs = this.remplirTableauCouleurs(this.couleurs);
		}

		// Cr�ation du contr�leur
		this.controleur = new Controleur_JeuMemoire(this);
		
		// M�langer les couleurs
		if(this.typeTableau) {
			this.imagesListe = Arrays.asList(this.images);
			this.melangerImages();
		}else {
			this.couleursListe = Arrays.asList(this.couleurs);
			this.melangerCouleurs();
		}		

		// Creation du Layout principal
		this.setLayout(new BorderLayout());

		// Partie du centre
		JPanel haut = new JPanel();
	
		//En fonction du nombre de cases (nombre de paires *2), on fabrique une grille diff�rente
		if(nombreDeCases == 4) {
			haut.setLayout(new GridLayout(nombreDeCases / 2, nombreDeCases / 2));
		}else if (nombreDeCases % 4 == 0 || nombreDeCases == 10) {
			haut.setLayout(new GridLayout(nombreDeCases / 4, nombreDeCases / 4));
		} else if (nombreDeCases == 14){
			haut.setLayout(new GridLayout(nombreDeCases / 5, nombreDeCases / 5));
		}else {
			haut.setLayout(new GridLayout(nombreDeCases / 2, nombreDeCases / 2));
		}
		
		//On fabrique tous les boutons de la grille avec une dimension fix�e et on y associe le controleur de la vue
		for (int i = 0; i < nombreDeCases; i++) {
			JButton b = new JButton();
			b.setPreferredSize(new Dimension(150, 150));
			this.tableauDesPaires[i] = b;
			haut.add(b);
			b.addActionListener(this.controleur);
		}

		// Partie du bas
		
		//On fabrique les diff�rents composants du bas et on y associe le controleur de la vue
		JPanel bas = new JPanel();
		bas.setLayout(new GridLayout(1, 3));

		this.nbCoups = new JLabel("  Nombre de coups :     0  ", JLabel.CENTER);
		bas.add(this.nbCoups);

		JButton valider = new JButton();
		valider.setText("Valider");
		valider.addActionListener(this.controleur);
		bas.add(valider);

		JButton reset = new JButton();
		reset.setText("Recommencer");
		reset.addActionListener(this.controleur);
		bas.add(reset);

		// ajout des JPanels dans la vue
		this.add(haut, BorderLayout.CENTER);
		this.add(bas, BorderLayout.SOUTH);
	}

	
	//
	
	
	// M�thodes de gestion du jeu

	//V�rifie que le bouton courant correspond aux boutons des paires
	public boolean appartientGrille(JButton b) {
		for (int i = 0; i < this.tableauDesPaires.length; i++) {
			if (this.tableauDesPaires[i] == b) {
				return true;
			}
		}
		return false;
	}

	//recherche dans quelle case de la grille des paires se situe le bouton courant
	public int quelleCase(JButton b) {
		for (int i = 0; i < this.tableauDesPaires.length; i++) {
			if (this.tableauDesPaires[i] == b) {
				return i;
			}
		}
		return 0;
	}

	//M�lange le tableau de couleurs al�atoirement
	public void melangerCouleurs() {
		Collections.shuffle(this.couleursListe);
		this.couleursListe.toArray(this.couleurs);
	}
	
	//M�lange le tableau d'images al�atoirement
	public void melangerImages() {
		Collections.shuffle(this.imagesListe);
		this.imagesListe.toArray(this.images);
	}

	//R�initialise le jeu sans recr�er de vue
	public void reinitialiser() {
		for (int i = 0; i < this.tableauDesPaires.length; i++) {
			this.tableauDesPaires[i].setEnabled(true);
			if(this.typeTableau) {
				this.tableauDesPaires[i].setIcon(null);
				this.melangerImages();
			}else {
				this.tableauDesPaires[i].setBackground(null);
				this.melangerCouleurs();
			}
		}
	}

	public int getNombreCases() {
		return this.nombreDeCases;
	}
	
	//On affecte leur couleur aux boutons des paires
	public Color[] remplirTableauCouleurs(Color[] couleurs) {
		for(int i = 0; i < this.nombreDeCases; i++) {
			couleurs[i] = this.couleursFinal[i];
		}
		return couleurs;
	}
	
	//On affecte leur image aux boutons des paires
	public ImageIcon[] remplirTableauImages(ImageIcon[] images) {
		for(int i = 0; i < this.nombreDeCases; i++) {
			images[i] = this.imagesFinal[i];
		}
		return images;
	}
	
	public Color[] getCouleurs() {
		return this.couleurs;
	}
	
	public ImageIcon[] getImages() {
		return this.images;
	}
	
	public void setTypeTableau(boolean typeTableau) {
		this.typeTableau = typeTableau;
	}
	
	public boolean getTypeTableau() {
		return this.typeTableau;
	}
	
	public void setDifficulte(int difficulte) {
		this.difficulte = difficulte;
	}
	
	public int getDifficulte() {
		return this.difficulte;
	}

}